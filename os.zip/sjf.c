/**
 * @file sjf.c
 * @brief Implémentation de l'algorithme d'ordonnancement SJF.
 *
 * Supporte plusieurs cycles CPU / E/S par processus.
 * À chaque décision d'ordonnancement, le processus prêt ayant
 * le PLUS COURT burst CPU courant est sélectionné.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdio.h>
#include <stdlib.h>
#include "sjf.h"

/* -----------------------------------------------------------------------
 * Fonctions internes
 * ----------------------------------------------------------------------- */

/**
 * @brief Compare deux processus par leur date d'arrivée (tri initial).
 */
static int compare_arrival(const void *a, const void *b)
{
    const Process *pa = (const Process *)a;
    const Process *pb = (const Process *)b;
    return pa->arrival_time - pb->arrival_time;
}

/* -----------------------------------------------------------------------
 * Implémentation publique
 * ----------------------------------------------------------------------- */

/**
 * @brief Exécute l'algorithme SJF sur un tableau de processus.
 *
 * Principe :
 *   - Même structure que FIFO, mais le critère de sélection est différent.
 *   - Parmi les processus prêts, on choisit celui dont le burst CPU
 *     COURANT est le plus court (pas le burst total initial).
 *   - En cas d'égalité : plus petit ready_time, puis plus petit pid.
 *   - La gestion des E/S bloquantes est identique à FIFO.
 *
 * @param processes  Tableau de processus à ordonnancer
 * @param n          Nombre de processus dans le tableau
 */
void sjf_schedule(Process processes[], int n)
{
    /* Tri initial par date d'arrivée (pour ready_time initial cohérent) */
    qsort(processes, n, sizeof(Process), compare_arrival);

    int burst_idx[MAX_PROCESSES];
    int ready_time[MAX_PROCESSES];
    int started[MAX_PROCESSES];
    int done[MAX_PROCESSES];

    for (int i = 0; i < n; i++) {
        burst_idx[i]  = 0;
        ready_time[i] = processes[i].arrival_time;
        started[i]    = 0;
        done[i]       = 0;
    }

    int current_time = 0;
    int done_count   = 0;

    while (done_count < n) {

        /* --- Chercher le processus prêt au burst CPU courant le plus court --- */
        int chosen = -1;
        for (int i = 0; i < n; i++) {
            if (done[i])                      continue;
            if (ready_time[i] > current_time) continue;

            if (chosen == -1) { chosen = i; continue; }

            int burst_i = processes[i].bursts[burst_idx[i]];
            int burst_c = processes[chosen].bursts[burst_idx[chosen]];

            /* Critère 1 : burst CPU courant le plus court */
            if (burst_i < burst_c) { chosen = i; continue; }
            if (burst_i > burst_c) continue;

            /* Critère 2 (égalité) : le plus ancien dans la file prête */
            if (ready_time[i] < ready_time[chosen]) { chosen = i; continue; }
            if (ready_time[i] > ready_time[chosen]) continue;

            /* Critère 3 (égalité) : plus petit pid */
            if (processes[i].pid < processes[chosen].pid) chosen = i;
        }

        /* --- File prête vide : avancer l'horloge --- */
        if (chosen == -1) {
            int next = -1;
            for (int i = 0; i < n; i++) {
                if (!done[i] && ready_time[i] > current_time)
                    if (next == -1 || ready_time[i] < next)
                        next = ready_time[i];
            }
            current_time = next;
            continue;
        }

        Process *p = &processes[chosen];

        if (!started[chosen]) {
            p->start_time    = current_time;
            p->response_time = current_time - p->arrival_time;
            started[chosen]  = 1;
        }

        /* Exécuter le burst CPU courant */
        current_time += p->bursts[burst_idx[chosen]];
        burst_idx[chosen]++;

        /* Burst E/S suivant ? */
        if (burst_idx[chosen] < p->nb_bursts) {
            ready_time[chosen]  = current_time + p->bursts[burst_idx[chosen]];
            burst_idx[chosen]++;
        } else {
            p->finish_time     = current_time;
            p->turnaround_time = p->finish_time - p->arrival_time;
            p->waiting_time    = p->turnaround_time - p->cpu_burst;
            done[chosen]       = 1;
            done_count++;
        }
    }
}
