/**
 * @file fifo.c
 * @brief Implémentation de l'algorithme d'ordonnancement FIFO (FCFS).
 *
 * Supporte plusieurs cycles CPU / E/S par processus.
 * Pendant un cycle E/S, le processus est bloqué : il ne consomme pas
 * le CPU et il ne compte pas dans la file prête.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdio.h>
#include <stdlib.h>
#include "fifo.h"

/* -----------------------------------------------------------------------
 * Fonctions internes
 * ----------------------------------------------------------------------- */

/**
 * @brief Compare deux processus par leur date d'arrivée.
 */
static int compare_arrival(const void *a, const void *b)
{
    const Process *pa = (const Process *)a;
    const Process *pb = (const Process *)b;
    return pa->arrival_time - pb->arrival_time;
}

/* -----------------------------------------------------------------------
 * Implémentation publique
 * ----------------------------------------------------------------------- */

/**
 * @brief Exécute l'algorithme FIFO sur un tableau de processus.
 *
 * Principe :
 *   - Les processus sont triés par date d'arrivée.
 *   - À chaque instant, le processus prêt ayant la date de disponibilité
 *     la plus ancienne est sélectionné (critère FIFO).
 *   - Un processus « prêt » est un processus arrivé et non bloqué en E/S.
 *   - Après un burst CPU, si le processus a un burst E/S suivant,
 *     il est bloqué jusqu'à la fin de ce burst E/S.
 *   - Quand la file prête est vide, l'horloge saute au prochain événement
 *     (arrivée ou fin d'E/S).
 *
 * Critère de sélection : ready_time minimal (= arrival_time pour la
 * première fois, = fin de l'E/S pour les fois suivantes).
 *
 * @param processes  Tableau de processus à ordonnancer
 * @param n          Nombre de processus dans le tableau
 */
void fifo_schedule(Process processes[], int n)
{
    /* Tri initial par date d'arrivée */
    qsort(processes, n, sizeof(Process), compare_arrival);

    /*
     * État local par processus :
     *   burst_idx[i]  : indice du prochain burst à exécuter
     *   ready_time[i] : date à partir de laquelle le processus est prêt
     *                   (arrival_time initialement, puis fin d'E/S)
     *   started[i]    : 1 si le processus a déjà utilisé le CPU
     *   done[i]       : 1 si le processus est terminé
     */
    int burst_idx[MAX_PROCESSES];
    int ready_time[MAX_PROCESSES];
    int started[MAX_PROCESSES];
    int done[MAX_PROCESSES];

    for (int i = 0; i < n; i++) {
        burst_idx[i]  = 0;
        ready_time[i] = processes[i].arrival_time;
        started[i]    = 0;
        done[i]       = 0;
    }

    int current_time = 0;
    int done_count   = 0;

    while (done_count < n) {

        /* --- Chercher le processus prêt le plus ancien (FIFO) --- */
        int chosen = -1;
        for (int i = 0; i < n; i++) {
            if (done[i])                       continue; /* déjà fini */
            if (ready_time[i] > current_time)  continue; /* pas encore prêt */

            if (chosen == -1 ||
                ready_time[i] < ready_time[chosen] ||
                (ready_time[i] == ready_time[chosen] &&
                 processes[i].pid < processes[chosen].pid))
            {
                chosen = i;
            }
        }

        /* --- File prête vide : avancer l'horloge au prochain événement --- */
        if (chosen == -1) {
            int next = -1;
            for (int i = 0; i < n; i++) {
                if (!done[i] && ready_time[i] > current_time)
                    if (next == -1 || ready_time[i] < next)
                        next = ready_time[i];
            }
            current_time = next;
            continue;
        }

        Process *p = &processes[chosen];

        /* Enregistrer la première exécution */
        if (!started[chosen]) {
            p->start_time    = current_time;
            p->response_time = current_time - p->arrival_time;
            started[chosen]  = 1;
        }

        /* Exécuter le burst CPU courant (burst_idx pointe toujours sur un CPU) */
        current_time += p->bursts[burst_idx[chosen]];
        burst_idx[chosen]++;

        /* Vérifier s'il y a un burst E/S suivant */
        if (burst_idx[chosen] < p->nb_bursts) {
            /*
             * burst_idx pointe maintenant sur un burst E/S.
             * Le processus est bloqué jusqu'à la fin de ce burst.
             * On avance burst_idx sur le prochain CPU burst.
             */
            ready_time[chosen]  = current_time + p->bursts[burst_idx[chosen]];
            burst_idx[chosen]++; /* sauter le burst E/S */
        } else {
            /* Plus aucun burst : le processus est terminé */
            p->finish_time     = current_time;
            p->turnaround_time = p->finish_time - p->arrival_time;
            p->waiting_time    = p->turnaround_time - p->cpu_burst;
            done[chosen]       = 1;
            done_count++;
        }
    }
}
