/**
 * @file rr.c
 * @brief Implémentation de l'algorithme d'ordonnancement Round Robin.
 *
 * Supporte plusieurs cycles CPU / E/S par processus.
 * Pendant un cycle E/S, le processus est bloqué : il est retiré de la
 * file prête et y revient automatiquement quand son E/S se termine.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdio.h>
#include <stdlib.h>
#include "rr.h"

/* Capacité de la file circulaire d'indices.
 * Un processus peut être enfilé plusieurs fois (une fois par quantum). */
#define RR_QUEUE_CAP (MAX_PROCESSES * 512)

/* -----------------------------------------------------------------------
 * Fonctions internes
 * ----------------------------------------------------------------------- */

/**
 * @brief Compare deux processus par leur date d'arrivée (tri initial).
 */
static int compare_arrival(const void *a, const void *b)
{
    const Process *pa = (const Process *)a;
    const Process *pb = (const Process *)b;
    return pa->arrival_time - pb->arrival_time;
}

/**
 * @brief Ajoute dans la file les processus devenus prêts à current_time.
 *
 * Deux sources de nouveaux processus prêts :
 *   1. Les processus qui viennent d'arriver (triés par arrival_time).
 *   2. Les processus dont le burst E/S vient de se terminer.
 *
 * Les arrivants sont ajoutés en premier ; les retours d'E/S ensuite.
 * io_finish[i] est remis à -1 dès que le processus est enfilé.
 *
 * @param q             File circulaire d'indices
 * @param tail          Pointeur sur la queue de la file
 * @param processes     Tableau de processus
 * @param n             Nombre de processus
 * @param next_arrival  Pointeur sur l'indice du prochain non encore arrivé
 * @param current_time  Horloge courante
 * @param io_finish     Tableau des dates de fin d'E/S (-1 si non bloqué)
 */
static void enqueue_ready(int q[], int *tail,
                           Process processes[], int n,
                           int *next_arrival, int current_time,
                           int io_finish[])
{
    /* 1. Nouveaux arrivants (dans l'ordre du tri par arrival_time) */
    while (*next_arrival < n &&
           processes[*next_arrival].arrival_time <= current_time) {
        q[(*tail) % RR_QUEUE_CAP] = (*next_arrival)++;
        (*tail)++;
    }

    /* 2. Processus dont l'E/S est terminée (dans l'ordre des indices) */
    for (int i = 0; i < n; i++) {
        if (io_finish[i] != -1 && io_finish[i] <= current_time) {
            q[(*tail) % RR_QUEUE_CAP] = i;
            (*tail)++;
            io_finish[i] = -1; /* marquer comme non bloqué */
        }
    }
}

/* -----------------------------------------------------------------------
 * Implémentation publique
 * ----------------------------------------------------------------------- */

/**
 * @brief Exécute l'algorithme Round Robin sur un tableau de processus.
 *
 * Principe :
 *   - Les processus prêts tournent à tour de rôle, chacun pendant
 *     au plus `quantum` ms (tranche de temps).
 *   - Si le burst CPU courant n'est pas terminé à la fin du quantum,
 *     le processus est replacé en fin de file prête.
 *   - Si le burst CPU courant SE TERMINE avant la fin du quantum,
 *     le processus passe en E/S (s'il en a une) ou se termine.
 *   - Pendant l'E/S, le processus est bloqué (io_finish[] > 0).
 *     Il revient dans la file prête automatiquement à la fin de l'E/S.
 *
 * @param processes  Tableau de processus à ordonnancer
 * @param n          Nombre de processus
 * @param quantum    Durée du quantum de temps (ms)
 */
void rr_schedule(Process processes[], int n, int quantum)
{
    /* Tri initial par date d'arrivée */
    qsort(processes, n, sizeof(Process), compare_arrival);

    /*
     * État local par processus :
     *   burst_idx[i]  : indice du burst CPU courant dans bursts[] (pair)
     *   remaining[i]  : temps restant dans le burst CPU courant
     *   io_finish[i]  : date de fin d'E/S (-1 si non bloqué)
     *   started[i]    : 1 si le processus a déjà utilisé le CPU
     */
    int burst_idx[MAX_PROCESSES];
    int remaining[MAX_PROCESSES];
    int io_finish[MAX_PROCESSES];
    int started[MAX_PROCESSES];

    for (int i = 0; i < n; i++) {
        burst_idx[i] = 0;
        remaining[i] = processes[i].bursts[0]; /* premier burst CPU */
        io_finish[i] = -1;
        started[i]   = 0;
    }

    /* File circulaire d'indices des processus prêts */
    int q[RR_QUEUE_CAP];
    int head         = 0;
    int tail         = 0;
    int next_arrival = 0;
    int current_time = 0;
    int done_count   = 0;

    /* Enfiler les processus déjà présents à t=0 */
    enqueue_ready(q, &tail, processes, n, &next_arrival, current_time, io_finish);

    while (done_count < n) {

        /* --- File prête vide : avancer au prochain événement --- */
        if (head == tail) {
            int next_event = -1;

            /* Chercher la prochaine fin d'E/S */
            for (int i = 0; i < n; i++) {
                if (io_finish[i] != -1)
                    if (next_event == -1 || io_finish[i] < next_event)
                        next_event = io_finish[i];
            }

            /* Comparer avec la prochaine arrivée */
            if (next_arrival < n) {
                int arr = processes[next_arrival].arrival_time;
                if (next_event == -1 || arr < next_event)
                    next_event = arr;
            }

            current_time = next_event;
            enqueue_ready(q, &tail, processes, n,
                          &next_arrival, current_time, io_finish);
        }

        /* --- Défiler le prochain processus prêt --- */
        int idx    = q[head % RR_QUEUE_CAP];
        head++;
        Process *p = &processes[idx];

        /* Enregistrer la première exécution */
        if (!started[idx]) {
            p->start_time    = current_time;
            p->response_time = current_time - p->arrival_time;
            started[idx]     = 1;
        }

        /* Calculer la durée de cette tranche */
        int run          = (remaining[idx] < quantum) ? remaining[idx] : quantum;
        current_time    += run;
        remaining[idx]  -= run;

        /* Ajouter les processus devenus prêts pendant cette tranche */
        enqueue_ready(q, &tail, processes, n,
                      &next_arrival, current_time, io_finish);

        if (remaining[idx] == 0) {
            /* Le burst CPU courant est terminé */
            burst_idx[idx]++;

            if (burst_idx[idx] < p->nb_bursts) {
                /*
                 * Il y a un burst E/S suivant : bloquer le processus.
                 * On calcule la fin d'E/S, puis on pointe burst_idx
                 * sur le prochain burst CPU et on initialise remaining.
                 */
                io_finish[idx]  = current_time + p->bursts[burst_idx[idx]];
                burst_idx[idx]++;                              /* sauter l'E/S  */
                remaining[idx]  = p->bursts[burst_idx[idx]];  /* prochain CPU  */
                /* Le processus sera ré-enfilé par enqueue_ready() */
            } else {
                /* Plus de bursts : processus terminé */
                p->finish_time     = current_time;
                p->turnaround_time = p->finish_time - p->arrival_time;
                p->waiting_time    = p->turnaround_time - p->cpu_burst;
                done_count++;
            }
        } else {
            /* Quantum épuisé mais burst non terminé : replacer en fin de file */
            q[tail % RR_QUEUE_CAP] = idx;
            tail++;
        }
    }
}
