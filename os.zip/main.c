/**
 * @file main.c
 * @brief Point d'entrée du simulateur d'ordonnancement.
 *
 * Usage :
 *   ./scheduler <fichier_processus.txt> <ALGO> [quantum]
 *
 * Format du fichier d'entrée :
 *   PID  arrival_time  burst1 [burst2 burst3 ...]
 * Les bursts alternent CPU et E/S. Le premier et le dernier sont toujours CPU.
 * Exemple :
 *   1  0  8 2 4     → CPU=8ms, E/S=2ms, CPU=4ms
 *   2  1  4         → CPU=4ms seulement
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "process.h"
#include "fifo.h"
#include "sjf.h"
#include "rr.h"
#include "metrics.h"

/**
 * @brief Charge les processus depuis un fichier texte.
 *
 * Chaque ligne contient : PID  arrival_time  burst1 [burst2 burst3 ...]
 * Les bursts alternent CPU / E/S et doivent être en nombre impair.
 * Si le nombre est pair, le dernier burst E/S est ignoré avec un avertissement.
 * Les lignes commençant par '#' sont ignorées (commentaires).
 *
 * @param filename   Chemin vers le fichier d'entrée
 * @param processes  Tableau de processus à remplir
 * @return           Nombre de processus chargés, -1 en cas d'erreur
 */
static int load_processes(const char *filename, Process processes[])
{
    FILE *f = fopen(filename, "r");
    if (!f) {
        perror("Erreur ouverture fichier");
        return -1;
    }

    int n = 0;
    char line[512];

    while (fgets(line, sizeof(line), f) && n < MAX_PROCESSES) {
        if (line[0] == '#' || line[0] == '\n') continue;

        Process p = {0};
        int offset;

        /* Lire PID et date d'arrivée */
        if (sscanf(line, "%d %d%n", &p.pid, &p.arrival_time, &offset) < 2)
            continue;

        /* Lire les bursts (nombre variable) */
        char *ptr = line + offset;
        int b, adv;
        while (sscanf(ptr, "%d%n", &b, &adv) == 1 && p.nb_bursts < MAX_BURSTS) {
            p.bursts[p.nb_bursts++] = b;
            ptr += adv;
        }

        if (p.nb_bursts == 0) continue; /* au moins un burst CPU requis */

        /* La séquence doit se terminer par un burst CPU (nb_bursts impair) */
        if (p.nb_bursts % 2 == 0) {
            fprintf(stderr,
                    "Avertissement P%d : nombre pair de bursts, "
                    "le dernier burst E/S est ignoré.\n", p.pid);
            p.nb_bursts--;
        }

        /* Calculer les totaux CPU et E/S */
        for (int i = 0; i < p.nb_bursts; i++) {
            if (i % 2 == 0) p.cpu_burst += p.bursts[i]; /* indices pairs = CPU */
            else            p.io_burst  += p.bursts[i]; /* indices impairs = E/S */
        }

        processes[n++] = p;
    }

    fclose(f);
    return n;
}

/**
 * @brief Point d'entrée principal.
 */
int main(int argc, char *argv[])
{
    if (argc < 3) {
        fprintf(stderr,
                "Usage : %s <fichier.txt> <ALGO> [quantum]\n"
                "  ALGO : FIFO | SJF | RR\n"
                "  quantum : requis pour RR (ex: 4)\n",
                argv[0]);
        return 1;
    }

    Process processes[MAX_PROCESSES];
    int n = load_processes(argv[1], processes);

    if (n <= 0) {
        fprintf(stderr, "Aucun processus chargé.\n");
        return 1;
    }

    printf("Chargement de %d processus depuis '%s'.\n", n, argv[1]);

    char *algo = argv[2];

    if (strcmp(algo, "FIFO") == 0) {
        fifo_schedule(processes, n);
        print_metrics(processes, n, "FIFO");
        save_csv(processes, n, "FIFO", "resultats_fifo.csv");
    }
    else if (strcmp(algo, "SJF") == 0) {
        sjf_schedule(processes, n);
        print_metrics(processes, n, "SJF");
        save_csv(processes, n, "SJF", "resultats_sjf.csv");
    }
    else if (strcmp(algo, "RR") == 0) {
        if (argc < 4) {
            fprintf(stderr, "Erreur : RR nécessite un quantum "
                            "(ex: ./scheduler procs.txt RR 4)\n");
            return 1;
        }
        int quantum = atoi(argv[3]);
        if (quantum <= 0) {
            fprintf(stderr, "Erreur : le quantum doit être strictement positif.\n");
            return 1;
        }
        rr_schedule(processes, n, quantum);
        print_metrics(processes, n, "RR");
        save_csv(processes, n, "RR", "resultats_rr.csv");
    }
    else {
        fprintf(stderr, "Algorithme inconnu : %s\n", algo);
        return 1;
    }

    return 0;
}
