/**
 * @file sjf.h
 * @brief Algorithme d'ordonnancement SJF (Shortest Job First).
 *
 * Non-préemptif : une fois un processus sélectionné, il s'exécute
 * jusqu'à la fin de son cycle CPU.
 * Critère de sélection : parmi les processus prêts, choisir celui
 * dont le cpu_burst est le plus court.
 * Départage : date d'arrivée, puis PID.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#ifndef SJF_H
#define SJF_H

#include "process.h"

/**
 * @brief Ordonnance les processus selon l'algorithme SJF.
 *
 * @param processes  Tableau de processus à ordonnancer
 * @param n          Nombre de processus
 */
void sjf_schedule(Process processes[], int n);

#endif /* SJF_H */
