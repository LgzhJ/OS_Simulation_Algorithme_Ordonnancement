/**
 * @file srjf.h
 * @brief Algorithme d'ordonnancement SRJF (Shortest Remaining Job First).
 *
 * Version préemptive de SJF : le processus en cours peut être interrompu
 * si un nouveau processus prêt a un burst CPU courant plus court.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#ifndef SRJF_H
#define SRJF_H

#include "process.h"

/**
 * @brief Ordonnance les processus selon l'algorithme SRJF.
 *
 * @param processes  Tableau de processus à ordonnancer
 * @param n          Nombre de processus
 */
void srjf_schedule(Process processes[], int n);

#endif /* SRJF_H */
