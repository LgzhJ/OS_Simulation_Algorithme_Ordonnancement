/**
 * @file fifo.c
 * @brief Implémentation de l'algorithme FIFO (FCFS) — version multi-burst.
 *
 * Non-préemptif : un processus s'exécute jusqu'à la fin de son cycle CPU
 * courant.  Après un cycle E/S intercalé, il réintègre la file d'attente
 * (derrière tous les processus déjà prêts à ce moment-là).
 *
 * Critère de sélection parmi les processus prêts :
 *   1. Date à laquelle le processus est devenu prêt (ready_since)
 *      = arrival_time pour le premier cycle CPU
 *      = io_finish_time pour les cycles suivants
 *   2. PID en départage.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdlib.h>
#include <limits.h>
#include "fifo.h"
#include "process.h"

/* ── Sélection ───────────────────────────────────────────────────────────── */

/**
 * @brief Renvoie la date à laquelle le processus est devenu (ou deviendra) prêt.
 *
 * Pour le premier cycle CPU : arrival_time.
 * Pour les cycles suivants  : io_finish_time du cycle E/S qui précède.
 */
static int ready_since(const Process *p)
{
    /* Si le processus n'a pas encore démarré, c'est son arrival_time.
     * Sinon, c'est la fin de son dernier cycle E/S. */
    if (!p->started)
        return p->arrival_time;
    return p->io_finish_time; /* valeur laissée par process_end_burst */
}

/**
 * @brief Choisit le processus prêt dont le ready_since est le plus ancien.
 * @return Indice du processus sélectionné, -1 si aucun n'est prêt.
 */
static int select_fifo(Process processes[], int n, int current_time)
{
    int chosen = -1;

    for (int i = 0; i < n; i++) {
        if (!process_is_ready(&processes[i], current_time)) continue;

        if (chosen == -1) {
            chosen = i;
            continue;
        }

        int rs_i = ready_since(&processes[i]);
        int rs_c = ready_since(&processes[chosen]);

        if (rs_i < rs_c || (rs_i == rs_c && processes[i].pid < processes[chosen].pid))
            chosen = i;
    }

    return chosen;
}

/**
 * @brief Retourne la date du prochain événement (arrivée ou fin d'E/S).
 *
 * Utilisée pour avancer l'horloge quand aucun processus n'est prêt.
 */
static int next_event_time(Process processes[], int n, int current_time)
{
    int t = INT_MAX;

    for (int i = 0; i < n; i++) {
        if (processes[i].done) continue;

        /* Processus pas encore arrivé */
        if (processes[i].arrival_time > current_time && processes[i].arrival_time < t)
            t = processes[i].arrival_time;

        /* Processus en E/S */
        int ev = process_next_event(&processes[i]);
        if (ev > current_time && ev < t)
            t = ev;
    }

    return t;
}

/* ── Implémentation ──────────────────────────────────────────────────────── */

void fifo_schedule(Process processes[], int n)
{
    for (int i = 0; i < n; i++)
        process_reset(&processes[i]);

    int current_time = 0;
    int done_count   = 0;

    while (done_count < n) {

        /* Réactiver les processus dont l'E/S est terminée */
        for (int i = 0; i < n; i++)
            process_resume(&processes[i], current_time);

        int chosen = select_fifo(processes, n, current_time);

        if (chosen == -1) {
            /* CPU inactif : avancer à l'événement le plus proche */
            int next = next_event_time(processes, n, current_time);
            if (next == INT_MAX) break; /* ne devrait pas arriver */
            current_time = next;
            continue;
        }

        Process *p = &processes[chosen];

        /* Pas besoin de rappeler process_resume(p, …) :
         * la boucle en début d'itération a déjà réactivé tous les processus
         * dont l'E/S était terminée, y compris celui-ci. */
        process_on_start(p, current_time);

        /* Exécution complète du burst courant (non-préemptif) */
        int run = process_run(p, p->remaining);
        current_time += run;

        /* Transition vers E/S, prochain burst ou fin */
        process_end_burst(p, current_time);
        if (process_is_done(p))
            done_count++;
    }
}
