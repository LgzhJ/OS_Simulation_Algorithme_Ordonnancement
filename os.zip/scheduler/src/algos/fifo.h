/**
 * @file fifo.h
 * @brief Algorithme d'ordonnancement FIFO (First In, First Out / FCFS).
 *
 * Non-préemptif : un processus s'exécute jusqu'à la fin de son cycle CPU.
 * Critère de sélection : date d'arrivée (le plus ancien d'abord).
 * E/S parallélisées : elles ne bloquent pas le CPU.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#ifndef FIFO_H
#define FIFO_H

#include "process.h"

/**
 * @brief Ordonnance les processus selon l'algorithme FIFO.
 *
 * Remplit les champs start_time, finish_time, waiting_time,
 * turnaround_time et response_time de chaque processus.
 *
 * @param processes  Tableau de processus à ordonnancer
 * @param n          Nombre de processus
 */
void fifo_schedule(Process processes[], int n);

#endif /* FIFO_H */
