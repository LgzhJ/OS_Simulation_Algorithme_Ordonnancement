/**
 * @file sjf.c
 * @brief Implémentation de l'algorithme SJF (Shortest Job First) — multi-burst.
 *
 * Non-préemptif : une fois sélectionné, le processus s'exécute jusqu'à la
 * fin de son cycle CPU **courant**.
 *
 * Critère de sélection parmi les processus prêts :
 *   1. Durée du cycle CPU courant (bursts[burst_idx * 2]) la plus courte.
 *   2. Date d'arrivée (arrival_time) la plus ancienne en départage.
 *   3. PID le plus petit en départage final.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <limits.h>
#include "sjf.h"
#include "process.h"

/* ── Sélection ───────────────────────────────────────────────────────────── */

/**
 * @brief Durée du cycle CPU courant d'un processus prêt.
 */
static int current_burst_duration(const Process *p)
{
    return p->bursts[p->burst_idx * 2];
}

/**
 * @brief Sélectionne le processus prêt ayant le plus court cycle CPU courant.
 * @return Indice du processus choisi, -1 si aucun n'est prêt.
 */
static int select_shortest(Process processes[], int n, int current_time)
{
    int chosen = -1;

    for (int i = 0; i < n; i++) {
        if (!process_is_ready(&processes[i], current_time)) continue;

        if (chosen == -1) {
            chosen = i;
            continue;
        }

        int d_i = current_burst_duration(&processes[i]);
        int d_c = current_burst_duration(&processes[chosen]);

        if (d_i < d_c)
            chosen = i;
        else if (d_i == d_c) {
            if (processes[i].arrival_time < processes[chosen].arrival_time)
                chosen = i;
            else if (processes[i].arrival_time == processes[chosen].arrival_time
                     && processes[i].pid < processes[chosen].pid)
                chosen = i;
        }
    }

    return chosen;
}

/**
 * @brief Date du prochain événement (arrivée ou fin d'E/S) parmi les non-terminés.
 */
static int next_event_time(Process processes[], int n, int current_time)
{
    int t = INT_MAX;

    for (int i = 0; i < n; i++) {
        if (processes[i].done) continue;

        if (processes[i].arrival_time > current_time
            && processes[i].arrival_time < t)
            t = processes[i].arrival_time;

        int ev = process_next_event(&processes[i]);
        if (ev > current_time && ev < t)
            t = ev;
    }

    return t;
}

/* ── Implémentation ──────────────────────────────────────────────────────── */

void sjf_schedule(Process processes[], int n)
{
    for (int i = 0; i < n; i++)
        process_reset(&processes[i]);

    int current_time = 0;
    int done_count   = 0;

    while (done_count < n) {

        /* Réactiver les processus dont l'E/S est terminée */
        for (int i = 0; i < n; i++)
            process_resume(&processes[i], current_time);

        int chosen = select_shortest(processes, n, current_time);

        if (chosen == -1) {
            int next = next_event_time(processes, n, current_time);
            if (next == INT_MAX) break;
            current_time = next;
            continue;
        }

        Process *p = &processes[chosen];

        /* Idem fifo.c : la boucle en début d'itération a déjà
         * réactivé tous les processus prêts, y compris celui-ci. */
        process_on_start(p, current_time);

        /* Burst entier (non-préemptif) */
        int run = process_run(p, p->remaining);
        current_time += run;

        process_end_burst(p, current_time);
        if (process_is_done(p))
            done_count++;
    }
}
