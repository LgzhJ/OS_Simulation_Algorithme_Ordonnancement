/**
 * @file rr.h
 * @brief Algorithme d'ordonnancement Round Robin (RR).
 *
 * Préemptif : chaque processus reçoit au maximum `quantum` ms de CPU.
 * S'il ne termine pas, il est replacé en fin de file d'attente.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#ifndef RR_H
#define RR_H

#include "process.h"

/**
 * @brief Ordonnance les processus selon l'algorithme Round Robin.
 *
 * @param processes  Tableau de processus à ordonnancer
 * @param n          Nombre de processus
 * @param quantum    Durée du quantum de temps (ms, doit être > 0)
 */
void rr_schedule(Process processes[], int n, int quantum);

#endif /* RR_H */
