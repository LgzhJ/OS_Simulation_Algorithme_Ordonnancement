/**
 * @file rr.c
 * @brief Implémentation de l'algorithme Round Robin — version multi-burst.
 *
 * Préemptif : chaque processus reçoit au plus `quantum` ms de CPU par tour.
 * S'il ne termine pas son burst, il est replacé en fin de file.
 *
 * Gestion multi-burst :
 *   - Un processus peut avoir plusieurs cycles CPU entrecoupés d'E/S.
 *   - Pendant un cycle E/S, le processus est bloqué (sorti de la file).
 *   - Il revient dans la file automatiquement quand son E/S se termine.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdlib.h>
#include <limits.h>
#include "rr.h"
#include "process.h"

/*
 * Taille de la file circulaire.
 *
 * Un processus est toujours dans exactement un de ces états :
 *   - en train de tourner sur le CPU   (1 au maximum)
 *   - dans la file prête               (au plus n - 1)
 *   - bloqué en E/S                    (pas dans la file)
 *   - terminé                          (pas dans la file)
 *
 * → La file ne contient jamais plus de n processus simultanément.
 *   MAX_PROCESSES est donc suffisant ; pas besoin de malloc.
 */
#define RR_QUEUE_CAP MAX_PROCESSES

/* ── Tri initial ─────────────────────────────────────────────────────────── */

static int compare_arrival(const void *a, const void *b)
{
    const Process *pa = (const Process *)a;
    const Process *pb = (const Process *)b;
    if (pa->arrival_time != pb->arrival_time)
        return pa->arrival_time - pb->arrival_time;
    return pa->pid - pb->pid;
}

/* ── Helpers de file circulaire ──────────────────────────────────────────── */

static void enqueue(int q[], int *tail, int idx)
{
    q[(*tail)++ % RR_QUEUE_CAP] = idx;
}

static int dequeue(int q[], int *head)
{
    return q[(*head)++ % RR_QUEUE_CAP];
}

/* ── Réintégration des processus prêts ──────────────────────────────────── */

/**
 * @brief Enfile les processus dont l'E/S vient de se terminer.
 *
 * Appelée après chaque tranche CPU pour récupérer les processus
 * qui étaient bloqués et dont la date de fin d'E/S est atteinte.
 * process_resume() remet in_io=0 et charge le prochain burst CPU.
 */
static void collect_io_done(Process processes[], int n,
                             int q[], int *tail, int current_time)
{
    for (int i = 0; i < n; i++) {
        if (processes[i].in_io && processes[i].io_finish_time <= current_time) {
            process_resume(&processes[i], current_time);
            enqueue(q, tail, i);
        }
    }
}

/* ── Avance de l'horloge ─────────────────────────────────────────────────── */

/**
 * @brief Retourne la date du prochain événement quand la file est vide.
 *
 * Deux types d'événements possibles :
 *   - Une arrivée non encore enfilée.
 *   - Une fin d'E/S d'un processus bloqué.
 */
static int next_event_time(Process processes[], int n,
                            int next_arrival_idx, int current_time)
{
    int t = INT_MAX;

    if (next_arrival_idx < n)
        t = processes[next_arrival_idx].arrival_time;

    for (int i = 0; i < n; i++)
        if (processes[i].in_io && processes[i].io_finish_time < t)
            t = processes[i].io_finish_time;

    return (t == INT_MAX) ? current_time : t;
}

/* ── Implémentation principale ───────────────────────────────────────────── */

void rr_schedule(Process processes[], int n, int quantum)
{
    for (int i = 0; i < n; i++)
        process_reset(&processes[i]);

    qsort(processes, n, sizeof(Process), compare_arrival);

    int q[RR_QUEUE_CAP];        /* file circulaire d'indices */
    int head             = 0;
    int tail             = 0;
    int next_arrival_idx = 0;   /* prochain processus pas encore enfilé */
    int current_time     = 0;
    int done_count       = 0;

    /* Enfiler les processus déjà présents à t = 0 */
    while (next_arrival_idx < n
           && processes[next_arrival_idx].arrival_time <= current_time)
        enqueue(q, &tail, next_arrival_idx++);

    while (done_count < n) {

        /* ── 1. File vide : sauter au prochain événement ── */
        if (head == tail) {
            current_time = next_event_time(processes, n,
                                           next_arrival_idx, current_time);
            while (next_arrival_idx < n
                   && processes[next_arrival_idx].arrival_time <= current_time)
                enqueue(q, &tail, next_arrival_idx++);

            collect_io_done(processes, n, q, &tail, current_time);
            continue;
        }

        /* ── 2. Exécuter la tranche du processus en tête de file ── */
        int idx    = dequeue(q, &head);
        Process *p = &processes[idx];

        process_resume(p, current_time);      /* réactive si retour d'E/S  */
        process_on_start(p, current_time);    /* enregistre start_time      */

        int run = process_run(p, quantum);    /* avance de min(remaining, quantum) */
        current_time += run;

        /* Enfiler les arrivées et les fins d'E/S survenues pendant la tranche */
        while (next_arrival_idx < n
               && processes[next_arrival_idx].arrival_time <= current_time)
            enqueue(q, &tail, next_arrival_idx++);

        collect_io_done(processes, n, q, &tail, current_time);

        /* ── 3. Que faire du processus courant ? ── */
        if (p->remaining == 0) {
            /* Burst CPU entièrement consommé */
            process_end_burst(p, current_time);

            if (process_is_done(p)) {
                done_count++;               /* terminé : on l'oublie        */
            } else if (!p->in_io) {
                enqueue(q, &tail, idx);    /* prochain burst CPU dispo      */
            }
            /* Si in_io == 1 : collect_io_done() le réenfilera plus tard. */
        } else {
            /* Quantum épuisé, burst non terminé : retour en fin de file */
            enqueue(q, &tail, idx);
        }
    }
}
