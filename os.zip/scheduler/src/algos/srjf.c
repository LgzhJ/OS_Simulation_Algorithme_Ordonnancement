/**
 * @file srjf.c
 * @brief Implémentation de l'algorithme SRJF (Shortest Remaining Job First).
 *
 * Version préemptive de SJF : à chaque événement (arrivée d'un processus
 * ou fin d'une E/S), le processus en cours peut être interrompu si un autre
 * a un burst CPU courant plus court.
 *
 * Critère de sélection parmi les processus prêts :
 *   1. Temps restant dans le burst CPU courant (remaining) le plus court.
 *   2. Date d'arrivée la plus ancienne en départage.
 *   3. PID le plus petit en départage final.
 *
 * Avance de l'horloge :
 *   Le processus sélectionné tourne jusqu'au PROCHAIN ÉVÉNEMENT
 *   (prochaine arrivée ou prochaine fin d'E/S), pas jusqu'à la fin de
 *   son burst. Cela permet de vérifier une éventuelle préemption sans
 *   avancer ms par ms.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <limits.h>
#include "srjf.h"
#include "process.h"

/* ── Sélection ───────────────────────────────────────────────────────────── */

/**
 * @brief Sélectionne le processus prêt ayant le moins de temps CPU restant.
 * @return Indice du processus choisi, -1 si aucun n'est prêt.
 */
static int select_shortest_remaining(Process processes[], int n, int current_time)
{
    int chosen = -1;

    for (int i = 0; i < n; i++) {
        if (!process_is_ready(&processes[i], current_time)) continue;

        if (chosen == -1) { chosen = i; continue; }

        int r_i = processes[i].remaining;
        int r_c = processes[chosen].remaining;

        if (r_i < r_c)
            chosen = i;
        else if (r_i == r_c) {
            if (processes[i].arrival_time < processes[chosen].arrival_time)
                chosen = i;
            else if (processes[i].arrival_time == processes[chosen].arrival_time
                     && processes[i].pid < processes[chosen].pid)
                chosen = i;
        }
    }

    return chosen;
}

/* ── Prochain point de préemption ────────────────────────────────────────── */

/**
 * @brief Retourne la date du prochain événement susceptible de causer une
 *        préemption (arrivée non encore traitée ou fin d'E/S).
 *
 * Le processus courant tourne jusqu'à cette date, puis on re-sélectionne.
 * Si aucun événement n'est prévu, retourne INT_MAX : le processus court
 * jusqu'à la fin de son burst.
 */
static int next_preemption_time(Process processes[], int n, int current_time)
{
    int t = INT_MAX;

    for (int i = 0; i < n; i++) {
        if (processes[i].done) continue;

        /* Prochaine arrivée */
        if (processes[i].arrival_time > current_time
            && processes[i].arrival_time < t)
            t = processes[i].arrival_time;

        /* Prochaine fin d'E/S */
        int ev = process_next_event(&processes[i]);
        if (ev > current_time && ev < t)
            t = ev;
    }

    return t;
}

/* ── Implémentation ──────────────────────────────────────────────────────── */

void srjf_schedule(Process processes[], int n)
{
    for (int i = 0; i < n; i++)
        process_reset(&processes[i]);

    int current_time = 0;
    int done_count   = 0;

    while (done_count < n) {

        /* Réactiver les processus dont l'E/S est terminée */
        for (int i = 0; i < n; i++)
            process_resume(&processes[i], current_time);

        int chosen = select_shortest_remaining(processes, n, current_time);

        /* ── Aucun processus prêt : avancer au prochain événement ── */
        if (chosen == -1) {
            int next = next_preemption_time(processes, n, current_time);
            if (next == INT_MAX) break; /* ne devrait pas arriver */
            current_time = next;
            continue;
        }

        Process *p = &processes[chosen];
        process_on_start(p, current_time);

        /*
         * Durée de cette tranche :
         *   min(remaining, temps jusqu'au prochain événement)
         *
         * Si aucun événement n'est prévu (INT_MAX), le processus tourne
         * jusqu'à la fin de son burst sans risque de préemption.
         */
        int next       = next_preemption_time(processes, n, current_time);
        int time_limit = (next == INT_MAX) ? p->remaining : (next - current_time);
        int run        = process_run(p, time_limit);
        current_time  += run;

        /* ── Fin de burst CPU : E/S, prochain burst, ou terminé ── */
        if (p->remaining == 0) {
            process_end_burst(p, current_time);
            if (process_is_done(p))
                done_count++;
        }
        /*
         * Si remaining > 0 : on a atteint un événement avant la fin du burst.
         * Le processus reste interruptible ; on re-sélectionne à la prochaine
         * itération (éventuellement un autre processus prendra le CPU).
         */
    }
}
