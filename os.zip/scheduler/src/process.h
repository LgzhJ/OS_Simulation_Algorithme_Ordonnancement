/**
 * @file process.h
 * @brief Définition et API d'auto-gestion d'un processus multi-burst.
 *
 * Un processus peut avoir plusieurs cycles CPU entrecoupés de cycles E/S.
 * Le tableau `bursts` stocke les durées en alternance :
 *   bursts[0] = cpu_0, bursts[1] = io_0, bursts[2] = cpu_1, ...
 *
 * Seuls les cycles E/S **intercalés** (entre deux CPU) bloquent le processus ;
 * l'éventuel cycle E/S final (après le dernier CPU) est parallélisé et
 * n'entre pas dans le calcul du turnaround ni du waiting_time.
 *
 * Métriques :
 *   finish_time     = fin du dernier cycle CPU
 *   turnaround_time = finish_time - arrival_time
 *   waiting_time    = turnaround_time - total_cpu - Σ(io intercalés)
 *   response_time   = start_time - arrival_time
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#ifndef PROCESS_H
#define PROCESS_H

/** Nombre maximum de processus supportés. */
#define MAX_PROCESSES 64

/**
 * Nombre maximum de cycles CPU par processus.
 * Le tableau bursts fait donc 2 * MAX_BURSTS entrées (cpu + io alternés).
 */
#define MAX_BURSTS 8

/* ─────────────────────────────────────────────────────────────────────────── */

typedef struct {

    /* ── Données d'entrée ────────────────────────────────────────────────── */
    int pid;
    int arrival_time;

    /**
     * Nombre de cycles CPU (= nb de paires dans bursts[]).
     * bursts[2*i]   = durée du i-ème cycle CPU  (ms)
     * bursts[2*i+1] = durée du i-ème cycle E/S  (ms, 0 si aucun)
     */
    int nb_bursts;
    int bursts[MAX_BURSTS * 2];

    int total_cpu; /**< Somme de tous les cycles CPU (ms) */
    int total_io;  /**< Somme de tous les cycles E/S déclarés (ms) */

    /* ── État de simulation ───────────────────────────────────────────────── */
    int burst_idx;      /**< Index du cycle CPU en cours (0 … nb_bursts-1) */
    int remaining;      /**< Temps CPU restant dans bursts[burst_idx*2] (ms) */
    int in_io;          /**< 1 si le processus est en phase E/S intercalée */
    int io_finish_time; /**< Date de fin de l'E/S courante */
    int started;        /**< 1 si le processus a déjà reçu le CPU */
    int done;           /**< 1 si le processus est complètement terminé */

    /* ── Métriques calculées ─────────────────────────────────────────────── */
    int start_time;
    int finish_time;
    int waiting_time;
    int turnaround_time;
    int response_time;

} Process;

/* ─────────────────────────────────────────────────────────────────────────── */

/**
 * @brief Réinitialise l'état de simulation (permet de relancer sans recharger).
 *
 * Remet burst_idx=0, remaining=bursts[0], started=done=in_io=0, métriques à 0.
 */
void process_reset(Process *p);

/**
 * @brief Indique si le processus est prêt à recevoir le CPU.
 *
 * Un processus est prêt s'il est arrivé, non terminé, et non bloqué en E/S.
 */
int process_is_ready(const Process *p, int current_time);

/** @brief Indique si le processus est totalement terminé. */
int process_is_done(const Process *p);

/**
 * @brief Enregistre le premier démarrage sur le CPU (répond idempotent).
 * Positionne start_time et response_time.
 */
void process_on_start(Process *p, int current_time);

/**
 * @brief Exécute le processus pendant au plus @p duration ms.
 * @return Temps CPU réellement consommé (≤ remaining).
 */
int process_run(Process *p, int duration);

/**
 * @brief Appelée quand remaining == 0 (fin d'un cycle CPU).
 *
 * Transitions possibles :
 *  - Dernier cycle CPU → process_finish() interne, done = 1.
 *  - Cycle CPU suivi d'E/S → in_io = 1, io_finish_time calculé, burst_idx++.
 *  - Cycle CPU sans E/S, mais d'autres suivent → burst_idx++, remaining mis à jour.
 */
void process_end_burst(Process *p, int current_time);

/**
 * @brief Retourne la date de fin de l'E/S courante, ou -1 si pas en E/S.
 *
 * Utilisée par les algorithmes pour savoir quand avancer l'horloge.
 */
int process_next_event(const Process *p);

/**
 * @brief Réactive un processus dont l'E/S vient de se terminer.
 *
 * Si in_io == 1 et io_finish_time <= current_time :
 *   - in_io = 0
 *   - remaining = durée du nouveau cycle CPU courant
 * Sans effet sinon.
 */
void process_resume(Process *p, int current_time);

/* process_finish() est interne à process.c (liaison statique).
 * Les algorithmes ne doivent pas l'appeler directement. */

#endif /* PROCESS_H */
