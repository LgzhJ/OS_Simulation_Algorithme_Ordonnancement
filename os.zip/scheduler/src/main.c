/**
 * @file main.c
 * @brief Point d'entrée du simulateur d'ordonnancement multi-burst.
 *
 * Usage :
 *   ./scheduler <fichier.txt> <ALGO> [quantum]
 *
 * Algorithmes disponibles : FIFO, SJF, RR, SRJF
 *
 * Format du fichier d'entrée (une ligne par processus) :
 *   PID  arrival_time  cpu0 [io0  cpu1 [io1  cpu2 ...]]
 *
 *   - Les valeurs après arrival_time alternent CPU et E/S.
 *   - La première valeur est toujours un cycle CPU.
 *   - Le cycle E/S final (après le dernier CPU) est parallélisé
 *     et n'influe pas sur le turnaround.
 *   - Les lignes commençant par '#' ou vides sont ignorées.
 *
 * Validation à la lecture :
 *   - Cycle CPU de 0 ms         → erreur, ligne ignorée
 *   - Valeur négative           → erreur, ligne ignorée
 *   - Plus de MAX_BURSTS cycles → erreur, ligne ignorée
 *   - Aucun cycle CPU           → erreur, ligne ignorée
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "process.h"
#include "metrics.h"
#include "algos/fifo.h"
#include "algos/sjf.h"
#include "algos/rr.h"
#include "algos/srjf.h"

/** Taille maximale d'une ligne dans le fichier d'entrée. */
#define LINE_BUF 512

/* ── Chargement des processus ────────────────────────────────────────────── */

/**
 * @brief Indique si une ligne doit être ignorée (commentaire ou vide).
 * @return 1 si la ligne est à ignorer, 0 sinon.
 */
static int is_blank_or_comment(const char *line)
{
    while (*line == ' ' || *line == '\t') line++;
    return (*line == '#' || *line == '\n' || *line == '\0');
}

/**
 * @brief Parse le PID et l'arrival_time d'une ligne déjà tokenisée.
 *
 * Appelle strtok(NULL, …) pour lire les deux premiers tokens.
 * @return 1 si succès, 0 si la ligne doit être ignorée.
 */
static int parse_header(int line_num, Process *p)
{
    char *tok = strtok(NULL, " \t\n\r");
    if (!tok) { return 0; }
    p->pid = atoi(tok);

    tok = strtok(NULL, " \t\n\r");
    if (!tok) {
        fprintf(stderr,
            "Erreur   ligne %d (PID %d) : arrival_time manquant."
            " Ligne ignorée.\n", line_num, p->pid);
        return 0;
    }
    p->arrival_time = atoi(tok);

    if (p->arrival_time < 0) {
        fprintf(stderr,
            "Erreur   ligne %d (PID %d) : arrival_time négatif (%d)."
            " Ligne ignorée.\n", line_num, p->pid, p->arrival_time);
        return 0;
    }

    return 1;
}

/**
 * @brief Parse et valide les valeurs de bursts (alternance cpu/io).
 *
 * Remplit p->bursts[] et écrit dans *nb_values le nombre de valeurs lues.
 * @return 1 si succès, 0 si la ligne doit être ignorée.
 */
static int parse_bursts(int line_num, Process *p, int *nb_values)
{
    int b = 0;

    char *tok;
    while ((tok = strtok(NULL, " \t\n\r")) != NULL) {
        int val = atoi(tok);

        if (b >= MAX_BURSTS * 2) {
            fprintf(stderr,
                "Erreur   ligne %d (PID %d) : trop de cycles CPU"
                " (maximum %d). Ligne ignorée.\n",
                line_num, p->pid, MAX_BURSTS);
            return 0;
        }

        if (val < 0) {
            fprintf(stderr,
                "Erreur   ligne %d (PID %d) : valeur négative (%d)"
                " à la position %d. Ligne ignorée.\n",
                line_num, p->pid, val, b);
            return 0;
        }

        if (b % 2 == 0 && val == 0) {
            fprintf(stderr,
                "Erreur   ligne %d (PID %d) : cycle CPU nul"
                " au burst %d. Ligne ignorée.\n",
                line_num, p->pid, b / 2 + 1);
            return 0;
        }

        p->bursts[b++] = val;
    }

    if (b == 0) {
        fprintf(stderr,
            "Erreur   ligne %d (PID %d) : aucun cycle CPU déclaré."
            " Ligne ignorée.\n", line_num, p->pid);
        return 0;
    }

    *nb_values = b;
    return 1;
}

/**
 * @brief Finalise un processus après parsing : calcule nb_bursts et les totaux.
 *
 * Règle de parité :
 *   b impair → dernier élément est un CPU sans E/S → padding io = 0
 *   b pair   → dernier élément est une E/S parallélisée
 */
static void finalize_process(Process *p, int b)
{
    if (b % 2 == 1) {
        p->bursts[b] = 0;           /* padding E/S implicite */
        p->nb_bursts = (b + 1) / 2;
    } else {
        p->nb_bursts = b / 2;
    }

    for (int i = 0; i < p->nb_bursts; i++) {
        p->total_cpu += p->bursts[i * 2];
        p->total_io  += p->bursts[i * 2 + 1];
    }

    process_reset(p);
}

/**
 * @brief Tente de parser une ligne en un processus valide.
 *
 * Orchestre parse_header(), parse_bursts() et finalize_process().
 * @return 1 si le processus est valide et a été rempli, 0 sinon.
 */
static int parse_line(char *line, int line_num, Process *p)
{
    *p = (Process){0};

    /* strtok() est appelé en chaîne : le premier token (PID) est consommé
     * ici, les suivants le seront dans parse_header() puis parse_bursts(). */
    strtok(line, " \t\n\r");           /* positionne strtok sur la ligne */

    if (!parse_header(line_num, p))    return 0;

    int nb_values = 0;
    if (!parse_bursts(line_num, p, &nb_values)) return 0;

    finalize_process(p, nb_values);
    return 1;
}

/**
 * @brief Charge et valide les processus depuis un fichier texte.
 *
 * @return Nombre de processus chargés (>= 0), -1 en cas d'erreur fatale.
 */
static int load_processes(const char *filename, Process processes[])
{
    FILE *f = fopen(filename, "r");
    if (!f) {
        perror("Erreur ouverture fichier");
        return -1;
    }

    int  n        = 0;
    int  line_num = 0;
    char line[LINE_BUF];

    while (fgets(line, sizeof(line), f) && n < MAX_PROCESSES) {
        line_num++;

        if (is_blank_or_comment(line)) continue;

        Process p;
        if (parse_line(line, line_num, &p))
            processes[n++] = p;
    }

    fclose(f);
    return n;
}

/* ── Aide ────────────────────────────────────────────────────────────────── */

static void print_usage(const char *prog)
{
    fprintf(stderr,
        "Usage : %s <fichier.txt> <ALGO> [quantum]\n"
        "\n"
        "  ALGO disponibles :\n"
        "    FIFO   — First In, First Out         (non-préemptif)\n"
        "    SJF    — Shortest Job First           (non-préemptif)\n"
        "    RR     — Round Robin                  (préemptif, quantum obligatoire)\n"
        "    SRJF   — Shortest Remaining Job First (préemptif)\n"
        "\n"
        "  Format du fichier :\n"
        "    PID  arrival  cpu0 [io0  cpu1 [io1 ...]]\n"
        "\n"
        "  Exemples :\n"
        "    %s data/test_processus.txt FIFO\n"
        "    %s data/test_processus.txt RR 4\n"
        "    %s data/test_processus.txt SRJF\n",
        prog, prog, prog, prog);
}

/* ── Point d'entrée ──────────────────────────────────────────────────────── */

int main(int argc, char *argv[])
{
    if (argc < 3) {
        print_usage(argv[0]);
        return 1;
    }

    Process processes[MAX_PROCESSES];
    int n = load_processes(argv[1], processes);

    if (n < 0) return 1; /* erreur fatale (fichier introuvable…) */

    if (n == 0) {
        fprintf(stderr,
            "Aucun processus valide chargé depuis '%s'.\n", argv[1]);
        return 1;
    }

    printf("Chargement de %d processus depuis '%s'.\n", n, argv[1]);

    const char *algo = argv[2];

    if (strcmp(algo, "FIFO") == 0) {
        fifo_schedule(processes, n);
        print_metrics(processes, n, "FIFO");
        save_csv(processes, n, "FIFO", "resultats_fifo.csv");

    } else if (strcmp(algo, "SJF") == 0) {
        sjf_schedule(processes, n);
        print_metrics(processes, n, "SJF");
        save_csv(processes, n, "SJF", "resultats_sjf.csv");

    } else if (strcmp(algo, "RR") == 0) {
        if (argc < 4) {
            fprintf(stderr,
                "Erreur : RR requiert un quantum.\n"
                "  Ex : %s data/test.txt RR 4\n", argv[0]);
            return 1;
        }
        int quantum = atoi(argv[3]);
        if (quantum <= 0) {
            fprintf(stderr, "Erreur : le quantum doit être un entier > 0.\n");
            return 1;
        }
        rr_schedule(processes, n, quantum);
        print_metrics(processes, n, "RR");
        save_csv(processes, n, "RR", "resultats_rr.csv");

    } else if (strcmp(algo, "SRJF") == 0) {
        srjf_schedule(processes, n);
        print_metrics(processes, n, "SRJF");
        save_csv(processes, n, "SRJF", "resultats_srjf.csv");

    } else {
        fprintf(stderr, "Algorithme inconnu : '%s'\n", algo);
        print_usage(argv[0]);
        return 1;
    }

    return 0;
}
