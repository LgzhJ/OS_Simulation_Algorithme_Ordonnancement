/**
 * @file process.c
 * @brief Implémentation de l'API d'auto-gestion d'un processus multi-burst.
 *
 * Ce module centralise toute la logique d'état et de calcul de métriques.
 * Les algorithmes passent exclusivement par ces fonctions : ils ne touchent
 * jamais directement les champs d'état.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include "process.h"

/* ── Déclaration anticipée ───────────────────────────────────────────────── */
/* process_finish est définie après process_end_burst qui l'appelle. */
static void process_finish(Process *p, int finish_time);

/* ── Réinitialisation ────────────────────────────────────────────────────── */

void process_reset(Process *p)
{
    p->burst_idx      = 0;
    p->remaining      = (p->nb_bursts > 0) ? p->bursts[0] : 0;
    p->in_io          = 0;
    p->io_finish_time = 0;
    p->started        = 0;
    p->done           = 0;
    p->start_time     = 0;
    p->finish_time    = 0;
    p->waiting_time   = 0;
    p->turnaround_time= 0;
    p->response_time  = 0;
}

/* ── Consultation d'état ─────────────────────────────────────────────────── */

int process_is_ready(const Process *p, int current_time)
{
    if (p->done)                                    return 0;
    if (p->arrival_time > current_time)             return 0;
    if (p->in_io && p->io_finish_time > current_time) return 0;
    return 1;
}

int process_is_done(const Process *p)
{
    return p->done;
}

/* ── Cycle de vie ────────────────────────────────────────────────────────── */

void process_on_start(Process *p, int current_time)
{
    if (!p->started) {
        p->start_time    = current_time;
        p->response_time = current_time - p->arrival_time;
        p->started       = 1;
    }
}

int process_run(Process *p, int duration)
{
    int run      = (duration < p->remaining) ? duration : p->remaining;
    p->remaining -= run;
    return run;
}

/* ── Fin de cycle CPU ────────────────────────────────────────────────────── */

void process_end_burst(Process *p, int current_time)
{
    /* Dernier cycle CPU → terminé */
    if (p->burst_idx >= p->nb_bursts - 1) {
        process_finish(p, current_time);
        return;
    }

    /* Il y a d'autres cycles CPU à venir */
    int io_dur = p->bursts[p->burst_idx * 2 + 1]; /* E/S après ce cycle */
    p->burst_idx++;

    if (io_dur > 0) {
        /* Phase E/S intercalée : bloque le processus */
        p->in_io          = 1;
        p->io_finish_time = current_time + io_dur;
        /* remaining sera mis à jour par process_resume() */
    } else {
        /* Pas d'E/S entre deux cycles CPU : prêt immédiatement */
        p->remaining = p->bursts[p->burst_idx * 2];
    }
}

int process_next_event(const Process *p)
{
    return p->in_io ? p->io_finish_time : -1;
}

void process_resume(Process *p, int current_time)
{
    if (p->in_io && p->io_finish_time <= current_time) {
        p->in_io     = 0;
        p->remaining = p->bursts[p->burst_idx * 2];
    }
}

/* ── Calcul des métriques finales ────────────────────────────────────────── */

static void process_finish(Process *p, int finish_time)
{
    p->finish_time     = finish_time;
    p->turnaround_time = finish_time - p->arrival_time;

    /*
     * Les cycles E/S intercalés (entre deux CPU) bloquent le processus et
     * sont donc exclus du waiting_time.
     * L'E/S finale (après le dernier CPU) est parallélisée → non soustraite.
     */
    int io_intermediate = 0;
    for (int i = 0; i < p->nb_bursts - 1; i++)
        io_intermediate += p->bursts[i * 2 + 1];

    p->waiting_time = p->turnaround_time - p->total_cpu - io_intermediate;
    p->done         = 1;
}
