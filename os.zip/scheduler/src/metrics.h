/**
 * @file metrics.h
 * @brief Calcul et affichage des indicateurs de performance.
 *
 * Module indépendant de l'algorithme utilisé.
 * Les processus doivent avoir été ordonnancés avant d'appeler ces fonctions.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#ifndef METRICS_H
#define METRICS_H

#include "process.h"

/**
 * @brief Affiche les résultats dans la console (format tabulaire).
 *
 * @param processes  Tableau de processus après ordonnancement
 * @param n          Nombre de processus
 * @param algo_name  Nom de l'algorithme (ex: "FIFO")
 */
void print_metrics(Process processes[], int n, const char *algo_name);

/**
 * @brief Sauvegarde les résultats dans un fichier CSV.
 *
 * Séparateur point-virgule, compatible tableur.
 *
 * @param processes  Tableau de processus après ordonnancement
 * @param n          Nombre de processus
 * @param algo_name  Nom de l'algorithme
 * @param filename   Chemin du fichier CSV de sortie
 */
void save_csv(Process processes[], int n, const char *algo_name,
              const char *filename);

#endif /* METRICS_H */
