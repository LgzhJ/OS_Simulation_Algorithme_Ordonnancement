/**
 * @file process.h
 * @brief Définition de la structure représentant un processus.
 *
 * Un processus exécute une séquence alternée de bursts CPU et E/S :
 *   bursts[0] = 1er CPU, bursts[1] = 1ère E/S, bursts[2] = 2ème CPU, ...
 * La séquence commence et se termine toujours par un burst CPU
 * (nb_bursts est donc toujours impair).
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#ifndef PROCESS_H
#define PROCESS_H

/** Nombre maximum de processus supportés */
#define MAX_PROCESSES 64

/** Nombre maximum de bursts par processus (CPU + E/S confondus) */
#define MAX_BURSTS 32

/**
 * @brief Structure représentant un processus à ordonnancer.
 */
typedef struct {
    int pid;             /**< Identifiant unique du processus */
    int arrival_time;    /**< Date d'arrivée dans la file (ms) */

    /* Séquence de bursts alternés CPU / E/S */
    int bursts[MAX_BURSTS]; /**< bursts[i] : durée du i-ème burst (ms) */
    int nb_bursts;          /**< Nombre total de bursts (toujours impair) */

    /* Totaux calculés à la lecture du fichier (utilisés par metrics.c) */
    int cpu_burst; /**< Somme de tous les bursts CPU (indices pairs) */
    int io_burst;  /**< Somme de tous les bursts E/S (indices impairs) */

    /* Champs calculés par l'ordonnanceur */
    int start_time;      /**< Date de première exécution sur le CPU */
    int finish_time;     /**< Date de fin d'exécution */
    int waiting_time;    /**< Temps passé en attente (ms) */
    int turnaround_time; /**< Temps de restitution : finish - arrival (ms) */
    int response_time;   /**< Temps de réponse : start - arrival (ms) */
} Process;

#endif /* PROCESS_H */
