/**
 * @file fifo.c
 * @brief Implémentation de l'algorithme d'ordonnancement FIFO (FCFS).
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdio.h>
#include <stdlib.h>
#include "fifo.h"
#include "sched_utils.h"

static int compare_arrival(const void *a, const void *b)
{
    const Process *pa = (const Process *)a;
    const Process *pb = (const Process *)b;
    return pa->arrival_time - pb->arrival_time;
}

/**
 * @brief Exécute l'algorithme FIFO.
 *
 * Critère de sélection : parmi les processus prêts, choisir celui
 * dont le ready_time est le plus ancien (arrivée ou retour d'E/S),
 * puis le plus petit pid en cas d'égalité.
 */
void fifo_schedule(Process processes[], int n)
{
    qsort(processes, n, sizeof(Process), compare_arrival);

    SchedState s;
    sched_init(&s, processes, n);

    int current_time = 0;
    int next_arrival = 0; /* indice du prochain processus pas encore arrivé */

    while (s.done_count < n) {

        /* Sélection FIFO : processus prêt au ready_time le plus ancien */
        int chosen = -1;
        for (int i = 0; i < n; i++) {
            if (!sched_is_ready(&s, i, current_time)) continue;
            if (chosen == -1
                || s.ready_time[i] < s.ready_time[chosen]
                || (s.ready_time[i] == s.ready_time[chosen]
                    && processes[i].pid < processes[chosen].pid))
                chosen = i;
        }

        /* Aucun processus prêt : avancer l'horloge */
        if (chosen == -1) {
            current_time = sched_next_event(&s, processes, n,
                                            next_arrival, current_time);
            /* Mettre à jour next_arrival après le saut d'horloge */
            while (next_arrival < n &&
                   processes[next_arrival].arrival_time <= current_time)
                next_arrival++;
            continue;
        }

        sched_record_start(&s, &processes[chosen], chosen, current_time);

        /* Exécuter le burst CPU courant en entier (FIFO = non préemptif) */
        current_time += processes[chosen].bursts[s.burst_idx[chosen]];

        sched_end_cpu_burst(&s, processes, chosen, current_time);
    }
}
