/**
 * @file sched_utils.h
 * @brief État partagé et fonctions utilitaires communs à tous les algorithmes.
 *
 * Ce module centralise la gestion des E/S bloquantes et du suivi d'état,
 * afin que chaque algorithme n'implémente que son propre critère de sélection.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#ifndef SCHED_UTILS_H
#define SCHED_UTILS_H

#include "process.h"

/** Capacité de la file circulaire utilisée par Round Robin */
#define RR_QUEUE_CAP (MAX_PROCESSES * 512)

/**
 * @brief État courant de chaque processus pendant la simulation.
 */
typedef struct {
    int burst_idx[MAX_PROCESSES];  /**< Indice du burst CPU courant (toujours pair) */
    int ready_time[MAX_PROCESSES]; /**< Date de disponibilité : arrival_time ou fin d'E/S */
    int in_io[MAX_PROCESSES];      /**< 1 si le processus est actuellement en E/S */
    int started[MAX_PROCESSES];    /**< 1 si start_time a déjà été enregistré */
    int done[MAX_PROCESSES];       /**< 1 si le processus est terminé */
    int done_count;                /**< Nombre de processus terminés */
} SchedState;

/**
 * @brief Initialise l'état de simulation.
 */
void sched_init(SchedState *s, Process processes[], int n);

/**
 * @brief Indique si le processus i est prêt à current_time.
 * Un processus prêt est arrivé, non bloqué en E/S et non terminé.
 * @return 1 si prêt, 0 sinon
 */
int sched_is_ready(const SchedState *s, int i, int current_time);

/**
 * @brief Enregistre la première exécution d'un processus (start_time, response_time).
 * N'a d'effet qu'à la première invocation pour un processus donné.
 */
void sched_record_start(SchedState *s, Process *p, int i, int current_time);

/**
 * @brief Traite la fin d'un burst CPU : bascule en E/S ou termine le processus.
 *
 * À appeler dès qu'un burst CPU s'est entièrement exécuté.
 * Met à jour ready_time, burst_idx, in_io, done et les métriques finales.
 *
 * @return 1 si le processus est terminé, 0 s'il est parti en E/S
 */
int sched_end_cpu_burst(SchedState *s, Process processes[], int i, int current_time);

/**
 * @brief Retourne la date du prochain événement quand aucun processus n'est prêt.
 * Cherche le minimum entre la prochaine arrivée et la prochaine fin d'E/S.
 */
int sched_next_event(const SchedState *s, Process processes[], int n,
                     int next_arrival, int current_time);

/**
 * @brief Enfile dans q[] les processus devenus prêts à current_time.
 *
 * Utilisée par Round Robin uniquement.
 * Ajoute d'abord les nouveaux arrivants (via next_arrival),
 * puis les processus dont le burst E/S vient de se terminer (in_io → 0).
 */
void sched_enqueue_ready(SchedState *s, Process processes[], int n,
                         int *next_arrival, int current_time,
                         int q[], int *tail);

#endif /* SCHED_UTILS_H */
