/**
 * @file sjf.c
 * @brief Implémentation de l'algorithme d'ordonnancement SJF.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdio.h>
#include <stdlib.h>
#include "sjf.h"
#include "sched_utils.h"

static int compare_arrival(const void *a, const void *b)
{
    const Process *pa = (const Process *)a;
    const Process *pb = (const Process *)b;
    return pa->arrival_time - pb->arrival_time;
}

/**
 * @brief Exécute l'algorithme SJF.
 *
 * Critère de sélection : parmi les processus prêts, choisir celui
 * dont le burst CPU COURANT est le plus court.
 * Départage : ready_time le plus ancien, puis plus petit pid.
 */
void sjf_schedule(Process processes[], int n)
{
    qsort(processes, n, sizeof(Process), compare_arrival);

    SchedState s;
    sched_init(&s, processes, n);

    int current_time = 0;
    int next_arrival = 0;

    while (s.done_count < n) {

        /* Sélection SJF : burst CPU courant le plus court parmi les prêts */
        int chosen = -1;
        for (int i = 0; i < n; i++) {
            if (!sched_is_ready(&s, i, current_time)) continue;
            if (chosen == -1) { chosen = i; continue; }

            int bi = processes[i].bursts[s.burst_idx[i]];
            int bc = processes[chosen].bursts[s.burst_idx[chosen]];

            if (bi < bc
                || (bi == bc && s.ready_time[i] < s.ready_time[chosen])
                || (bi == bc && s.ready_time[i] == s.ready_time[chosen]
                    && processes[i].pid < processes[chosen].pid))
                chosen = i;
        }

        if (chosen == -1) {
            current_time = sched_next_event(&s, processes, n,
                                            next_arrival, current_time);
            while (next_arrival < n &&
                   processes[next_arrival].arrival_time <= current_time)
                next_arrival++;
            continue;
        }

        sched_record_start(&s, &processes[chosen], chosen, current_time);

        current_time += processes[chosen].bursts[s.burst_idx[chosen]];

        sched_end_cpu_burst(&s, processes, chosen, current_time);
    }
}
