/**
 * @file sched_utils.c
 * @brief Implémentation des utilitaires partagés entre les algorithmes.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdio.h>
#include <stdlib.h>
#include "sched_utils.h"

/* -----------------------------------------------------------------------
 * Initialisation
 * ----------------------------------------------------------------------- */

void sched_init(SchedState *s, Process processes[], int n)
{
    for (int i = 0; i < n; i++) {
        s->burst_idx[i]  = 0;
        s->ready_time[i] = processes[i].arrival_time;
        s->in_io[i]      = 0;
        s->started[i]    = 0;
        s->done[i]       = 0;
    }
    s->done_count = 0;
}

/* -----------------------------------------------------------------------
 * Test de disponibilité
 * ----------------------------------------------------------------------- */

int sched_is_ready(const SchedState *s, int i, int current_time)
{
    return !s->done[i]
        && !s->in_io[i]
        && s->ready_time[i] <= current_time;
}

/* -----------------------------------------------------------------------
 * Première exécution
 * ----------------------------------------------------------------------- */

void sched_record_start(SchedState *s, Process *p, int i, int current_time)
{
    if (!s->started[i]) {
        p->start_time    = current_time;
        p->response_time = current_time - p->arrival_time;
        s->started[i]    = 1;
    }
}

/* -----------------------------------------------------------------------
 * Fin de burst CPU
 * ----------------------------------------------------------------------- */

int sched_end_cpu_burst(SchedState *s, Process processes[], int i, int current_time)
{
    Process *p = &processes[i];
    s->burst_idx[i]++; /* dépasser le burst CPU qui vient de finir */

    if (s->burst_idx[i] < p->nb_bursts) {
        /* Un burst E/S suit : bloquer le processus */
        s->ready_time[i]  = current_time + p->bursts[s->burst_idx[i]];
        s->in_io[i]       = 1;
        s->burst_idx[i]++;  /* pointer sur le prochain burst CPU */
        return 0;           /* bloqué en E/S */
    }

    /* Plus de bursts : processus terminé */
    p->finish_time     = current_time;
    p->turnaround_time = p->finish_time - p->arrival_time;
    p->waiting_time    = p->turnaround_time - p->cpu_burst;
    s->done[i]         = 1;
    s->done_count++;
    return 1; /* terminé */
}

/* -----------------------------------------------------------------------
 * Prochain événement (horloge morte)
 * ----------------------------------------------------------------------- */

int sched_next_event(const SchedState *s, Process processes[], int n,
                     int next_arrival, int current_time)
{
    int next = -1;

    /* Prochaine fin d'E/S */
    for (int i = 0; i < n; i++) {
        if (s->in_io[i])
            if (next == -1 || s->ready_time[i] < next)
                next = s->ready_time[i];
    }

    /* Prochaine arrivée */
    if (next_arrival < n) {
        int arr = processes[next_arrival].arrival_time;
        if (next == -1 || arr < next)
            next = arr;
    }

    return next;
}

/* -----------------------------------------------------------------------
 * Enfilage des processus prêts (Round Robin)
 * ----------------------------------------------------------------------- */

void sched_enqueue_ready(SchedState *s, Process processes[], int n,
                         int *next_arrival, int current_time,
                         int q[], int *tail)
{
    /* 1. Nouveaux arrivants */
    while (*next_arrival < n &&
           processes[*next_arrival].arrival_time <= current_time) {
        q[(*tail) % RR_QUEUE_CAP] = *next_arrival;
        (*tail)++;
        (*next_arrival)++;
    }

    /* 2. Retours d'E/S : in_io était 1 et le processus est maintenant prêt */
    for (int i = 0; i < n; i++) {
        if (s->in_io[i] && s->ready_time[i] <= current_time) {
            s->in_io[i] = 0; /* débloquer avant d'enfiler */
            q[(*tail) % RR_QUEUE_CAP] = i;
            (*tail)++;
        }
    }
}
