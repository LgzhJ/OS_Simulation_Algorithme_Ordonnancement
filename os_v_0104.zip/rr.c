/**
 * @file rr.c
 * @brief Implémentation de l'algorithme d'ordonnancement Round Robin.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#include <stdio.h>
#include <stdlib.h>
#include "rr.h"
#include "sched_utils.h"

static int compare_arrival(const void *a, const void *b)
{
    const Process *pa = (const Process *)a;
    const Process *pb = (const Process *)b;
    return pa->arrival_time - pb->arrival_time;
}

/**
 * @brief Exécute l'algorithme Round Robin.
 *
 * Chaque processus prêt reçoit au plus `quantum` ms de CPU.
 * S'il ne termine pas, il est replacé en fin de file.
 * S'il termine son burst CPU, sched_end_cpu_burst() le bascule
 * en E/S (in_io=1) ou le marque terminé.
 * sched_enqueue_ready() le réenfile automatiquement à la fin de l'E/S.
 */
void rr_schedule(Process processes[], int n, int quantum)
{
    qsort(processes, n, sizeof(Process), compare_arrival);

    SchedState s;
    sched_init(&s, processes, n);

    /* remaining[i] : temps CPU restant dans le burst courant */
    int remaining[MAX_PROCESSES];
    for (int i = 0; i < n; i++)
        remaining[i] = processes[i].bursts[0];

    int q[RR_QUEUE_CAP];
    int head         = 0;
    int tail         = 0;
    int next_arrival = 0;
    int current_time = 0;

    /* Enfiler les processus présents à t=0 */
    sched_enqueue_ready(&s, processes, n, &next_arrival, current_time, q, &tail);

    while (s.done_count < n) {

        /* File prête vide : sauter au prochain événement */
        if (head == tail) {
            current_time = sched_next_event(&s, processes, n,
                                            next_arrival, current_time);
            sched_enqueue_ready(&s, processes, n,
                                &next_arrival, current_time, q, &tail);
        }

        int idx = q[head % RR_QUEUE_CAP];
        head++;

        sched_record_start(&s, &processes[idx], idx, current_time);

        /* Exécuter la tranche */
        int run        = (remaining[idx] < quantum) ? remaining[idx] : quantum;
        current_time  += run;
        remaining[idx] -= run;

        /* Ajouter les processus devenus prêts pendant la tranche */
        sched_enqueue_ready(&s, processes, n,
                            &next_arrival, current_time, q, &tail);

        if (remaining[idx] == 0) {
            /* Burst CPU terminé : E/S ou fin de processus */
            sched_end_cpu_burst(&s, processes, idx, current_time);

            /* Si le processus est reparti en E/S, préparer le prochain burst CPU */
            if (s.in_io[idx] && s.burst_idx[idx] < processes[idx].nb_bursts)
                remaining[idx] = processes[idx].bursts[s.burst_idx[idx]];
        } else {
            /* Quantum épuisé, burst non terminé : replacer en fin de file */
            q[tail % RR_QUEUE_CAP] = idx;
            tail++;
        }
    }
}
