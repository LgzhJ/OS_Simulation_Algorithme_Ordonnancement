/**
 * @file rr.h
 * @brief Déclaration de l'algorithme d'ordonnancement Round Robin.
 *
 * @authors NOM1 (xx%), NOM2 (xx%), NOM3 (xx%)
 */

#ifndef RR_H
#define RR_H

#include "process.h"

/**
 * @brief Exécute l'algorithme Round Robin.
 *
 * @param processes  Tableau de processus à ordonnancer
 * @param n          Nombre de processus
 * @param quantum    Durée du quantum de temps (ms)
 */
void rr_schedule(Process processes[], int n, int quantum);

#endif /* RR_H */
